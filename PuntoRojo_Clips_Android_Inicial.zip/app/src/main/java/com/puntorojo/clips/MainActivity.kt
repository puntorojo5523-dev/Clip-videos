package com.puntorojo.clips

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Rojo = Color(0xFFE31B3D)
private val Fondo = Color(0xFF101116)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClipsScreen() }
    }
}

@Composable
private fun ClipsScreen() {
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Selecciona un video para comenzar.") }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        selectedVideo = uri
        status = if (uri != null) {
            "Video seleccionado. El motor de clips se integrará en la siguiente etapa."
        } else {
            "No se seleccionó ningún video."
        }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Fondo) {
            Column(
                Modifier.fillMaxSize().padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔴", style = MaterialTheme.typography.headlineLarge)
                    Column(Modifier.padding(start = 10.dp)) {
                        Text("PuntoRojo Clips", color = Color.White,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold)
                        Text("Convierte videos largos en momentos cortos",
                            color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF20222B)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("TU PROYECTO", color = Rojo, fontWeight = FontWeight.Bold)
                        Text("10 clips · Subtítulos en español · Vertical 9:16",
                            color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Text("Versión inicial de la interfaz. Estamos preparando la importación y el procesamiento de video.",
                            color = Color.LightGray)
                        Button(
                            onClick = { picker.launch(arrayOf("video/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Seleccionar video del teléfono") }
                        Text(selectedVideo?.lastPathSegment ?: "Ningún video seleccionado",
                            color = Color(0xFFBFC2CC))
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF20222B)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ESTADO", color = Rojo, fontWeight = FontWeight.Bold)
                        Text(status, color = Color.White)
                        OutlinedButton(
                            onClick = {
                                status = "La detección automática, subtítulos y exportación todavía no están integrados."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Revisar estado del proyecto") }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("Desarrollado por PuntoRojo Up", color = Color.Gray,
                    modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}
