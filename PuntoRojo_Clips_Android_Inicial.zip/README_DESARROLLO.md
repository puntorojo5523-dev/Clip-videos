# PuntoRojo Clips — Android starter

Este paquete contiene la estructura inicial de una aplicación Android con Kotlin y Jetpack Compose.

## Incluye
- Pantalla inicial PuntoRojo Clips.
- Selector de videos locales mediante el selector seguro de Android.
- Configuración Gradle.
- Flujo de GitHub Actions para generar un APK de depuración.

## Compilar
Requiere JDK 17 y Gradle 8.9:
```bash
gradle assembleDebug
```
El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Estado
Esta es una base de interfaz y compilación. Todavía no incluye detección automática de momentos, transcripción/subtítulos ni renderizado/exportación de clips.

Los enlaces de YouTube deben manejarse respetando los permisos del titular y las condiciones de la plataforma. La app no descarga videos protegidos ni elude restricciones.
